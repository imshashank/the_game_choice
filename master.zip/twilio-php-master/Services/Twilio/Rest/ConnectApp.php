<?php

class Services_Twilio_Rest_ConnectApp
    extends Services_Twilio_InstanceResource
{
}
